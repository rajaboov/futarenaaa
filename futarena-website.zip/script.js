document.querySelectorAll('.book-btn').forEach(button => {
    button.addEventListener('click', () => {
        alert('Booking feature coming soon!');
    });
});